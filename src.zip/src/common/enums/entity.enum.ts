export enum EntityName {
    Event = "event",
    Reservation = "reservation",
    User = "user",
    Category = "category",
    Otp= "otp"
  }
  