export enum Roles {
    ADMIN = 'admin',
    USER = 'user'
}