export type CookiePayload = {
    userId: number
}
export type AccessTokenPayload = {
    userId: number;
}

export type PhoneTokenPayload = {
    phone: string;
}