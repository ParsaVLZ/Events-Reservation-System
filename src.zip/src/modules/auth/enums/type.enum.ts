export enum AuthType {
    LOGIN = "login",
    REGISTER = "register",
  }
  