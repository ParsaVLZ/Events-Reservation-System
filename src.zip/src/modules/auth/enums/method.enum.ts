export enum AuthMethod {
    PASSWORD = "password",
    OTP = "otp",
    Phone="phone",
  }
  