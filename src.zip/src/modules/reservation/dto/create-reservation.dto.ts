import { IsNumber, IsEnum, IsNotEmpty } from 'class-validator';
import { ReservationStatus } from '../enums/reservation-status.enum';
import { ApiProperty } from '@nestjs/swagger';

export class CreateReservationDto {
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  eventId: number;
  @IsNumber()
  @IsNotEmpty()
  userId: number;
  @IsNumber()
  @IsNotEmpty()
  @ApiProperty()
  quantity: number;
  @IsEnum(ReservationStatus)
  status: ReservationStatus;
}
